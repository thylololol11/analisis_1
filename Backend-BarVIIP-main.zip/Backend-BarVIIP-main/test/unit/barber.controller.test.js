const { generateHash } = require("../../src/services/Bcrypt.js");
const Barber = require("../../src/models/Barbers.js");
const { MongoService } = require("../../src/services/MongoService.js");
const BarberController = require("../../src/controllers/barber.controller");

jest.mock("../../src/services/Bcrypt.js");
jest.mock("../../src/models/Barbers.js");
jest.mock("../../src/services/MongoService");

describe("BarberController", () => {
  let req;
  let res;
  let controller;
  let mockBarber;
  let mockMongoService;

  beforeEach(() => {
    req = {
      body: {},
      params: {},
      files: {},
    };
    res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };
    mockBarber = {
      valid: jest.fn(),
    };
    Barber.mockReturnValue(mockBarber);

    mockMongoService = {
      findOne: jest.fn(),
      update: jest.fn(),
      deleteOne: jest.fn(),
    };

    MongoService.mockReturnValue(mockMongoService);
    generateHash.mockResolvedValue("hashedPassword");

    controller = new BarberController();
  });

  describe("createBarber", () => {
    it("should create a barber successfully", async () => {
      // Arrange
      req.body = {
        email: "barber@test.com",
        password: "password",
        confirmPassword: "password",
      };
      generateHash.mockResolvedValue("hashedPassword");
      MongoService.prototype.findOne.mockResolvedValue(null);
      MongoService.prototype.create.mockResolvedValue({ insertedId: "123" });

      // Act
      await controller.createBarber(req, res);

      // Assert
      expect(res.status).toHaveBeenCalledWith(201);
      expect(res.json).toHaveBeenCalledWith({
        ok: true,
        message: "Barber created successfully",
        info: {
          email: "barber@test.com",
          password: "hashedPassword",
          _id: "123",
        },
      });
    });
    it("should respond with an error if the email already exists", async () => {
      // Arrange
      req.body = {
        email: "barber@test.com",
        password: "password",
        confirmPassword: "password",
      };
      generateHash.mockResolvedValue("hashedPassword");
      MongoService.prototype.findOne.mockResolvedValue({ _id: "123" }); // Simula que ya existe un barbero con el mismo correo electrónico

      // Act
      try {
        await controller.createBarber(req, res);
      } catch (error) {
        // Assert
        expect(error.status).toBe(400);
        expect(error.message).toBe("Exist already email");
      }
    });

    it("should respond with an error if there is an unexpected error", async () => {
      // Arrange
      req.body = {
        email: "barber@test.com",
        password: "password",
        confirmPassword: "password",
      };
      generateHash.mockResolvedValue("hashedPassword");
      MongoService.prototype.findOne.mockResolvedValue(null);
      const mockError = new Error("Unexpected error");
      MongoService.prototype.create.mockRejectedValue(mockError); // Simula un error inesperado

      // Act
      try {
        await controller.createBarber(req, res);
      } catch (error) {
        // Assert
        expect(error).toBe(mockError);
      }
    });

    // Add more test cases for different scenarios
  });

  describe("deleteBarber", () => {
    it("should delete a barber successfully", async () => {
      // Arrange
      req.params = {
        id: "123",
      };
      MongoService.prototype.delete.mockResolvedValue({ deletedCount: 1 });

      // Act
      await controller.deleteBarber(req, res);

      // Assert
      expect(res.status).toHaveBeenCalledWith(200);
      expect(res.json).toHaveBeenCalledWith({
        ok: true,
        message: "Barber deleted successfully",
        info: {},
      });
    });
    it("should respond with an error if the barber is not found", async () => {
      // Arrange
      req.params = {
        id: "123",
      };
      MongoService.prototype.delete.mockResolvedValue({ deletedCount: 0 }); // Simula que el barbero no se encuentra en la base de datos

      // Act
      try {
        await controller.deleteBarber(req, res);
      } catch (error) {
        // Assert
        expect(error.status).toBe(404);
        expect(error.message).toBe("Barber not found in database.");
      }
    });

    it("should respond with an error if there is an unexpected error", async () => {
      // Arrange
      req.params = {
        id: "123",
      };
      const mockError = new Error("Unexpected error");
      MongoService.prototype.delete.mockRejectedValue(mockError); // Simula un error inesperado

      // Act
      try {
        await controller.deleteBarber(req, res);
      } catch (error) {
        // Assert
        expect(error).toBe(mockError);
      }
    });

    // Add more test cases for different scenarios
  });

  describe("updateBarber", () => {
    it("should update a barber successfully", async () => {
      // Arrange
      req.params = {
        id: "123",
      };
      req.body = {
        email: "updated@test.com",
        password: "updatedPassword",
      };
      generateHash.mockResolvedValue("updatedHashedPassword");
      MongoService.prototype.update.mockResolvedValue({ modifiedCount: 1 });

      // Act
      await controller.updateBarber(req, res);

      // Assert
      expect(res.status).toHaveBeenCalledWith(200);
      expect(res.json).toHaveBeenCalledWith({
        ok: true,
        message: "Barber edited succesfully",
        info: {
          email: "updated@test.com",
          password: "updatedHashedPassword",
        },
      });
    })
    it("should respond with an error if the barber is not found", async () => {
      // Arrange
      req.params = {
        id: "123",
      };
      req.body = {
        email: "updated@test.com",
        password: "updatedPassword",
      };
      generateHash.mockResolvedValue("updatedHashedPassword");
      MongoService.prototype.update.mockResolvedValue({ modifiedCount: 0 }); // Simula que el barbero no se encuentra en la base de datos

      // Act
      try {
        await controller.updateBarber(req, res);
      } catch (error) {
        // Assert
        expect(error.status).toBe(404);
        expect(error.message).toBe("Barber not found");
      }
    });

    it("should respond with an error if the email is already registered", async () => {
      // Arrange
      req.params = {
        id: "123",
      };
      req.body = {
        email: "updated@test.com",
        password: "updatedPassword",
      };
      generateHash.mockResolvedValue("updatedHashedPassword");
      MongoService.prototype.findOne.mockResolvedValue({ _id: "456" }); // Simula que el correo electrónico ya está registrado por otro barbero

      // Act
      try {
        await controller.updateBarber(req, res);
      } catch (error) {
        // Assert
        expect(error.status).toBe(400);
        expect(error.message).toBe("Email is already registered");
      }
    });

  });

  describe("getBarber", () => {
    it("should get a barber successfully", async () => {
      // Arrange
      req.params = {
        id: "123",
      };
      const expectedBarber = {
        _id: "123",
        email: "barber@test.com",
        password: "hashedPassword",
      };
      MongoService.prototype.findOne.mockResolvedValue(expectedBarber);

      // Act
      await controller.getBarber(req, res);

      // Assert
      expect(res.status).toHaveBeenCalledWith(404);
      expect(res.json).toHaveBeenCalledWith({
        ok: false,
        message: "Barber not found",
      });
    })
    it("should respond with an error if the barber is not found", async () => {
      // Arrange
      req.params = {
        id: "123",
      };
      MongoService.prototype.getById.mockResolvedValue(null); // Simula que el barbero no se encuentra en la base de datos
  
      // Act
      await controller.getBarber(req, res);
  
      // Assert
      expect(res.status).toHaveBeenCalledWith(404);
      expect(res.json).toHaveBeenCalledWith({
        ok: false,
        message: "Barber not found",
      });
    });
  
    it("should get a barber successfully", async () => {
      // Arrange
      req.params = {
        id: "123",
      };
      const expectedBarber = {
        _id: "123",
        email: "barber@test.com",
        password: "hashedPassword",
      };
      MongoService.prototype.getById.mockResolvedValue(expectedBarber); // Simula que el barbero se encuentra en la base de datos
  
      // Act
      await controller.getBarber(req, res);
  
      // Assert
      expect(res.status).toHaveBeenCalledWith(200);
      expect(res.json).toHaveBeenCalledWith({
        ok: true,
        message: "Barber found",
        info: expectedBarber,
      });
    });

  });

  describe("saveImage", () => {
    it("should save an image successfully", async () => {
      // Arrange
      req.params = {
        id: "123",
      };
      req.files = {
        image: {
          mv: jest.fn().mockResolvedValue(),
        },
      };
      const expectedBarber = {
        _id: "123",
        email: "barber@test.com",
        password: "hashedPassword",
        image: "/uploads/123.jpg",
      };
      MongoService.prototype.update.mockResolvedValue({ modifiedCount: 1 });

      // Act
      try {
        await controller.saveImage(req, res);
      } catch (error) {
        console.error(error);
        res.status(error?.status || 500).json({
          ok: false,
          message: error?.message || error,
        });
      }

      // Assert
      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        ok: false,
        message: { status: 400 },
      });
    })
    it("should respond with an error if no image is provided", async () => {
      // Arrange
      req.params = {
        id: "123",
      };
      req.files = {}; // Simula que no se proporcionó una imagen
  
      // Act
      await controller.saveImage(req, res);
  
      // Assert
      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        ok: false,
        message: { status: 400 },
      });
    });
  
    it("should save an image successfully", async () => {
      // Arrange
      req.params = {
        id: "123",
      };
      req.files = {
        img: {
          name: "test.jpg",
          md5: "testMd5",
          mv: jest.fn().mockResolvedValue(),
        },
      };
      const expectedBarber = {
        _id: "123",
        email: "barber@test.com",
        password: "hashedPassword",
        img: "/uploads/testMd5test.jpg",
      };
      MongoService.prototype.getById.mockResolvedValue(expectedBarber);
      MongoService.prototype.update.mockResolvedValue({ modifiedCount: 1 });
  
      // Act
      await controller.saveImage(req, res);
  
      // Assert
      expect(res.status).toHaveBeenCalledWith(200);
      expect(res.json).toHaveBeenCalledWith({
        ok: true,
        message: "Imagen del usuario guardado",
        info: expectedBarber,
      });
    });


  })
  describe("allBarbers", () => {
    it("should get all barbers successfully", async () => {
      // Arrange
      const expectedBarbers = [
        {
          _id: "123",
          email: "barber1@test.com",
          password: "hashedPassword1",
        },
        {
          _id: "456",
          email: "barber2@test.com",
          password: "hashedPassword2",
        },
      ];
      MongoService.prototype.findAll.mockResolvedValue(expectedBarbers);
  
      // Act
      await controller.allBarbers(req, res);
  
      // Assert
      expect(res.status).toHaveBeenCalledWith(200);
      expect(res.json).toHaveBeenCalledWith({
        ok: true,
        message: "Consulted barbers",
        info: expectedBarbers,
      });
    });
  
    it("should handle errors correctly", async () => {
      // Arrange
      const expectedError = { status: 500, message: "Database error" };
      MongoService.prototype.findAll.mockRejectedValue(expectedError);
  
      // Act
      await controller.allBarbers(req, res);
  
      // Assert
      expect(res.status).toHaveBeenCalledWith(500);
      expect(res.json).toHaveBeenCalledWith({
        ok: false,
        message: "Database error",
      });
    });
  });

});
