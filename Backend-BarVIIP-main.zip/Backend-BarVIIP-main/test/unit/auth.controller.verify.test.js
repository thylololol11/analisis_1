
// All necessary imports here
const { AuthController } = require('../../src/controllers/auth.controller'); // Adjust the path accordingly
const { MongoService } = require("../../src/services/MongoService");
const { compareHash } = require("../../src/services/Bcrypt");
const { createToken, verifyToken } = require("../../src/services/JwtService");
const jwt = require("jsonwebtoken");

jest.mock("../../src/services/MongoService");
jest.mock("../../src/services/Bcrypt");
jest.mock("../../src/services/JwtService");
jest.mock("jsonwebtoken");

describe("AuthController", () => {
  let authController;
  let mockRequest;
  let mockResponse;
  
  beforeEach(() => {
    authController = new AuthController();
    mockRequest = { body: {} };
    mockResponse = {
      status: jest.fn(() => mockResponse),
      json: jest.fn(),
    };

    MongoService.prototype.findOne = jest.fn();
    compareHash.mockClear();
    createToken.mockClear();
    verifyToken.mockClear();
    mockResponse.status.mockClear();
    mockResponse.json.mockClear();
  });

  describe("verifyToken", () => {
    it("should verify a valid token", async () => {
      mockRequest.body = { token: 'validToken' };
      verifyToken.mockReturnValue({ id: 'userId' });

      await authController.verifyToken(mockRequest, mockResponse);

      expect(mockResponse.status).toHaveBeenCalledWith(200);
      expect(mockResponse.json).toHaveBeenCalledWith(expect.objectContaining({
        ok: true,
        message: "Token verificado",
      }));
    });

    it("should handle invalid token scenario", async () => {
      mockRequest.body = { token: 'invalidToken' };
      verifyToken.mockImplementation(() => {
        throw new jwt.TokenExpiredError();
      });

      await authController.verifyToken(mockRequest, mockResponse);

      expect(mockResponse.status).toHaveBeenCalledWith(400);
      expect(mockResponse.json).toHaveBeenCalledWith(expect.objectContaining({
        ok: false,
        message: "Token no valido",
      }));
    });

    it("should handle errors during token verification", async () => {
      mockRequest.body = { token: 'erroredToken' };
      verifyToken.mockImplementation(() => {
        throw { status: 500, message: "Internal Server Error" };
      });

      await authController.verifyToken(mockRequest, mockResponse);

      expect(mockResponse.status).toHaveBeenCalledWith(500);
      expect(mockResponse.json).toHaveBeenCalledWith(expect.objectContaining({
        ok: false,
        message: "Internal Server Error",
      }));
    })
  });
});
