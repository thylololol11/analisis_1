const { generateHash } = require("../../src/services/Bcrypt.js");
const User = require("../../src/models/Users.js");
const { MongoService } = require("../../src/services/MongoService.js");
const UsersController = require("../../src/controllers/user.controller.js");

jest.mock("../../src/services/Bcrypt.js");
jest.mock("../../src/models/Users.js");
jest.mock("../../src/services/MongoService");

describe("UsersController", () => {
  let req;
  let res;
  let controller;
  let mockUser;
  let mockMongoService;

  beforeEach(() => {
    req = {
      body: {},
      params: { id: "123" },
      files: {},
    };
    res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };
    mockUser = {
      valid: jest.fn(),
    };
    User.mockReturnValue(mockUser);

    mockMongoService = {
      findOne: jest.fn(),
      update: jest.fn(),
      getById: jest.fn(),
    };

    MongoService.mockReturnValue(mockMongoService);
    generateHash.mockResolvedValue("hashedPassword");

    controller = new UsersController();
  });

  describe("createUser", () => {
    it("should create a user successfully", async () => {
      // Arrange
      req.body = {
        email: "test@test.com",
        password: "password",
        confirmPassword: "password",
      };
      generateHash.mockResolvedValue("hashedPassword");
      MongoService.prototype.findOne.mockResolvedValue(null);
      MongoService.prototype.create.mockResolvedValue({ insertedId: "123" });

      // Act
      await controller.createUser(req, res);

      // Assert
      expect(res.status).toHaveBeenCalledWith(201);
      expect(res.json).toHaveBeenCalledWith({
        ok: true,
        message: "User created successfully",
        info: {
          email: "test@test.com",
          password: "hashedPassword",
          _id: "123",
        },
      });
    })
    it("should respond with an error if the email already exists", async () => {
      // Arrange
      req.body = {
        email: "test@test.com",
        password: "password",
        confirmPassword: "password",
      };
      generateHash.mockResolvedValue("hashedPassword");
      MongoService.prototype.findOne.mockResolvedValue({ _id: "123" }); // Simula que ya existe un usuario con el mismo correo electrónico
  
      // Act
      try {
        await controller.createUser(req, res);
      } catch (error) {
        // Assert
        expect(error.status).toBe(400);
        expect(error.message).toBe("Exist already email");
      }
    })
    it("should respond with an error if there is an unexpected error", async () => {
      // Arrange
      req.body = {
        email: "test@test.com",
        password: "password",
        confirmPassword: "password",
      };
      generateHash.mockResolvedValue("hashedPassword");
      MongoService.prototype.findOne.mockResolvedValue(null);
      const mockError = new Error("Unexpected error");
      MongoService.prototype.create.mockRejectedValue(mockError); // Simula un error inesperado
  
      // Act
      try {
        await controller.createUser(req, res);
      } catch (error) {
        // Assert
        expect(error).toBe(mockError);
      }
    });

    // Add more test cases for different scenarios
  });

  describe("deleteUser", () => {
    it("should delete a user successfully", async () => {
      // Arrange
      req.params.id = "123";
      MongoService.prototype.delete.mockResolvedValue({ deleteCount: 1 });

      // Act
      await controller.deleteUser(req, res);

      // Assert
      expect(res.status).toHaveBeenCalledWith(200);
      expect(res.json).toHaveBeenCalledWith({
        ok: true,
        message: "User deleted successfully",
        info: {},
      });
    });

    it("should throw an error when user not found", async () => {
      // Arrange
      req.params.id = "123";
      MongoService.prototype.delete.mockResolvedValue({ deleteCount: 0 });

      // Act
      await controller.deleteUser(req, res);

      // Assert
      expect(res.status).toHaveBeenCalledWith(404);
      expect(res.json).toHaveBeenCalledWith({
        ok: false,
        message: "User not found in database",
      });
    });

    // Add more test cases for different scenarios
  });

  describe("updateUser", () => {
    it("should update a user successfully", async () => {
      // Arrange
      req.body = {
        name: "Sebastian1",
        lastName: "GonzalezTrujillo",
        email: "holi@gmail.com",
        password: "sebastian",
        confirmPassword: "sebastian",
        img: "...",
      };
      req.params.id = "66244f76b321298d7b77b228";

      MongoService.prototype.update.mockResolvedValue({ modifiedCount: 1 });
      MongoService.prototype.findOne.mockResolvedValue({
        _id: "66244f76b321298d7b77b228",
      });

      // Act
      await controller.updateUser(req, res);

      // Assert
      /* expect(MongoService.prototype.update.mockResolvedValue).toHaveBeenCalled(); */
      expect(res.status).toHaveBeenCalledWith(200);
      expect(res.json).toHaveBeenCalledWith({
        ok: true,
        message: "User edited succesfully",
        info: req.body,
      });
    });

    it("should throw an error when user not found", async () => {
      // Arrange
      req.body = {
        email: "test@test.com",
        password: "password",
        confirmPassword: "password",
      };
      req.params.id = "66244f76b321298d7b77b228";
      MongoService.prototype.update.mockResolvedValue({ modifiedCount: 0 });
      MongoService.prototype.findOne.mockResolvedValue({
        _id: "66244f76b321298d7b77b228",
      });

      // Act
      await controller.updateUser(req, res);

      // Assert
      expect(res.status).toHaveBeenCalledWith(404);
      expect(res.json).toHaveBeenCalledWith({
        ok: false,
        message: "User not found",
      });
    });

    it("should throw an error when email is already registered", async () => {
      // Arrange
      req.body = {
        email: "test@test.com",
        password: "password",
        confirmPassword: "password",
      };
      req.params.id = "166245eb9d6001089608ccb7523";
      /*  mockMongoService.update.mockImplementation(() => Promise.resolve({ modifiedCount: 1 })); */
      mockMongoService.findOne.mockResolvedValue({
        _id: "65f31f63430ce7bb8632aeee",
      });

      // Act
      await controller.updateUser(req, res);

      // Assert
      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        ok: false,
        message: "Email is already registered",
      });
    });

    describe("   getUser   ", () => {
      it("should return user if found", async () => {
        // Arrange
        const user = { _id: "123", name: "Test User" };
        MongoService.prototype.getById.mockResolvedValue(user);
        const controller = new UsersController();

        // Act
        await controller.getUser(req, res);

        // Assert
        expect(MongoService.prototype.getById).toHaveBeenCalledWith(
          "users",
          "123"
        );
        expect(res.status).toHaveBeenCalledWith(200);
        expect(res.json).toHaveBeenCalledWith({
          ok: true,
          message: "User found",
          info: user,
        });
      });

      it("should return 404 if user not found", async () => {
        // Arrange
        MongoService.prototype.getById.mockResolvedValue(null);
        const controller = new UsersController();

        // Act
        await controller.getUser(req, res);

        // Assert
        expect(MongoService.prototype.getById).toHaveBeenCalledWith(
          "users",
          "123"
        );
        expect(res.status).toHaveBeenCalledWith(404);
        expect(res.json).toHaveBeenCalledWith({
          ok: false,
          message: "User not found",
        });
      });

      it("should return 500 if an error occurs", async () => {
        // Arrange
        const error = new Error("Test error");
        MongoService.prototype.getById.mockRejectedValue(error);
        const controller = new UsersController();

        // Act
        await controller.getUser(req, res);

        // Assert
        expect(MongoService.prototype.getById).toHaveBeenCalledWith(
          "users",
          "123"
        );
        expect(res.status).toHaveBeenCalledWith(500);
        expect(res.json).toHaveBeenCalledWith({
          ok: false,
          message: "Test error",
        });
      });
    });
    describe("saveImage", () => {
      it("should save an image successfully", async () => {
        // Arrange
        req.params = {
          id: "123",
        };
        req.files = {
          img: {
            mv: jest.fn().mockResolvedValue(),
            md5: "md5",
            name: "name",
          },
        };
        const expectedUser = {
          _id: "123",
          email: "user@test.com",
          password: "hashedPassword",
          img: "http://localhost/static/md5name",
        };
        MongoService.prototype.getById.mockResolvedValue(expectedUser);
        MongoService.prototype.update.mockResolvedValue({ modifiedCount: 1 });

        // Act
        await controller.saveImage(req, res);

        // Assert
        expect(res.status).toHaveBeenCalledWith(200); // Verificar que una función ha sido llamada con argumentos específicos
        expect(res.json).toHaveBeenCalledWith({
          ok: true,
          message: "Imagen del usuario guardado",
          info: expectedUser,
        });
      });

      it("should fail when no image is provided", async () => {
        // Arrange
        req.params = {
          id: "123",
        };
        req.files = {};

        // Act
        try {
          await controller.saveImage(req, res);
        } catch (error) {
          // Assert
          expect(res.status).toHaveBeenCalledWith(400);  //Fluent asertions
          expect(res.json).toHaveBeenCalledWith({       //Fluent asertions
            ok: false,
            message: { status: 400 },
          });
        }
      });

      // Add more test cases for different scenarios
    });
  });
});

// Add similar tests for updateUser, getUser, saveImage
