// Importa los módulos necesarios
const { AuthController } = require('../../src/controllers/auth.controller');
const { MongoService } = require('../../src/services/MongoService');
const { createToken } = require('../../src/services/JwtService');
const { compareHash } = require('../../src/services/Bcrypt');

// Burla los módulos
jest.mock('../../src/services/MongoService');
jest.mock('../../src/services/JwtService');
jest.mock('../../src/services/Bcrypt');

// Describe el conjunto de pruebas
describe('AuthController', () => {
  let mockRequest;
  let mockResponse;
  let authController;

  // Configura el entorno para cada prueba
  beforeAll(() => {
    mockRequest = {
      body: {},
    };
    mockResponse = {
      status: jest.fn(() => mockResponse),
      json: jest.fn(),
    };
    authController = new AuthController();
  });

  // Describe las pruebas para el método login
  describe('login', () => {
    // Prueba: autenticar al usuario y responder con el token
    it('should authenticate user and respond with token', async () => {
      // Arrange
      const mockUser = {
        email: 'test@example.com',
        password: 'password',
      };
      const mockToken = 'mockToken';

      // Configura los comportamientos de los mocks
      MongoService.prototype.findOne.mockReturnValueOnce(mockUser);
      compareHash.mockReturnValueOnce(true);
      createToken.mockReturnValueOnce(mockToken);

      mockRequest.body = mockUser;

      // Act
      await authController.login(mockRequest, mockResponse);

      // Assert
      expect(MongoService.prototype.findOne).toHaveBeenCalledWith('users', { email: mockUser.email });
      expect(compareHash).toHaveBeenCalledWith('password', 'password');
      expect(createToken).toHaveBeenCalledWith({ email: mockUser.email, type: 'User' });
      expect(mockResponse.status).toHaveBeenCalledWith(200);
      expect(mockResponse.json).toHaveBeenCalledWith({
        ok: true,
        message: "It's good to see you again",
        info: { ...mockUser, token: mockToken },
      });
    });

    // Prueba: responder con error para usuario inválido
    it('should respond with error for invalid user', async () => {
      // Arrange
      const mockUser = {
        email: 'test@example.com',
        password: 'wrongpassword',
      };

      // Configura el comportamiento del mock de MongoService para devolver null
      MongoService.prototype.findOne.mockReturnValueOnce(null);
      

      mockRequest.body = mockUser;

      // Act
      await authController.login(mockRequest, mockResponse);

      // Assert
      expect(MongoService.prototype.findOne).toHaveBeenCalledWith('users', { email: mockUser.email });
      expect(mockResponse.status).toHaveBeenCalledWith(404);
      expect(mockResponse.json).toHaveBeenCalledWith({
        ok: false,
        message: 'Invalid user',
      });
    });

    // Otras pruebas para el método login
  });

  // Otras descripciones y pruebas
});
