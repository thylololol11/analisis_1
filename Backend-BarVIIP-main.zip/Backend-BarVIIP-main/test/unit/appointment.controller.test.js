const { MongoService } = require("../../src/services/MongoService.js");
const AppointmentController = require("../../src/controllers/appointment.controller.js");

// Crea mocks de las dependencias
jest.mock("../../src/services/MongoService.js");

describe("AppointmentController", () => {
  let controller;
  let mockRequest;
  let mockResponse;

  beforeEach(() => {
    // Crea una nueva instancia del controlador antes de cada prueba
    controller = new AppointmentController();

    // Crea objetos de solicitud y respuesta simulados
    mockRequest = {
      params: {
        id: "123",
      },
      body: {
        idBarber: "123",
        idUser: "1",
        date: "2022-77-12",
        hour: "12:00",
        address: "123 St",
        nameBarber: "John",
      },
    };
    mockResponse = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    // Resetea los mocks de las dependencias
    MongoService.mockClear();
  });
  describe("CreateAppointment", () => {
    it("should create an appointment successfully", async () => {
      // Arrange
      const mockAppointment = { ...mockRequest.body, _id: "456" };
      MongoService.prototype.create.mockResolvedValue({ insertedId: "456" });
      MongoService.prototype.findOne.mockResolvedValue(null);

      // Act
      await controller.createAppointment(mockRequest, mockResponse);

      // Assert
      expect(MongoService.prototype.create).toHaveBeenCalledWith(
        "appointments",
        mockRequest.body
      );
      expect(mockResponse.status).toHaveBeenCalledWith(201);
      expect(mockResponse.json).toHaveBeenCalledWith({
        ok: true,
        message: "Appointment created",
        info: mockAppointment,
      });
    });

    it("should handle errors correctly", async () => {
      // Arrange
      const mockError = new Error("Test error");
      MongoService.prototype.create.mockRejectedValue(mockError);

      // Act
      await controller.createAppointment(mockRequest, mockResponse);

      // Assert
      expect(mockResponse.status).toHaveBeenCalledWith(500);
      expect(mockResponse.json).toHaveBeenCalledWith({
        ok: false,
        message: "Test error",
      });
    });
    describe("Delete appoinmets", () => {
      it("should delete an appointment successfully", async () => {
        // Arrange
        MongoService.prototype.delete.mockResolvedValue({ deleteCount: 1 });

        // Act
        await controller.deleteAppointment(mockRequest, mockResponse);

        // Assert
        expect(MongoService.prototype.delete).toHaveBeenCalledWith(
          "appointments",
          "123"
        );
        expect(mockResponse.status).toHaveBeenCalledWith(200);
        expect(mockResponse.json).toHaveBeenCalledWith({
          ok: true,
          message: "Appointment deleted",
          info: {},
        });
      });

      it("should handle errors correctly", async () => {
        // Arrange
        const mockError = new Error("Test error");
        MongoService.prototype.delete.mockRejectedValue(mockError);

        // Act
        await controller.deleteAppointment(mockRequest, mockResponse);

        // Assert
        expect(mockResponse.status).toHaveBeenCalledWith(500);
        expect(mockResponse.json).toHaveBeenCalledWith({
          ok: false,
          message: "Test error",
        });
      });

      it("should handle case when no appointment is found", async () => {
        // Arrange
        MongoService.prototype.delete.mockResolvedValue({ deleteCount: 0 });

        // Act
        await controller.deleteAppointment(mockRequest, mockResponse);

        // Assert
        expect(mockResponse.status).toHaveBeenCalledWith(400);
        expect(mockResponse.json).toHaveBeenCalledWith({
          ok: false,
          message: "There is no appointment created",
        });
      });
    });

    describe("AppointmentController", () => {
      it("should update an appointment successfully", async () => {
        // Arrange

        const mockAppointment = { ...mockRequest.body };
        MongoService.prototype.update.mockResolvedValue({ modifiedCount: 1 });

        // Act
        await controller.updateAppointment(mockRequest, mockResponse);

        // Assert
        expect(MongoService.prototype.update).toHaveBeenCalledWith(
          "appointments",
          mockRequest.body,
          mockRequest.params.id
        );
        expect(mockResponse.status).toHaveBeenCalledWith(200);
        expect(mockResponse.json).toHaveBeenCalledWith({
          ok: true,
          message: "Appointment updated",
          info: mockAppointment,
        });
      });

      it("should handle errors correctly when updating", async () => {
        // Arrange
        const mockError = new Error("Test error");
        MongoService.prototype.update.mockRejectedValue(mockError);

        // Act
        await controller.updateAppointment(mockRequest, mockResponse);

        // Assert
        expect(mockResponse.status).toHaveBeenCalledWith(500);
        expect(mockResponse.json).toHaveBeenCalledWith({
          ok: false,
          message: "Test error",
        });
      });

      it("should handle case when no appointment is found to update", async () => {
        // Arrange
        MongoService.prototype.update.mockResolvedValue({ modifiedCount: 0 });

        // Act
        await controller.updateAppointment(mockRequest, mockResponse);

        // Assert
        expect(mockResponse.status).toHaveBeenCalledWith(409);
        expect(mockResponse.json).toHaveBeenCalledWith({
          ok: false,
          message: "Update failed",
        });
      });
    });
  });
});
