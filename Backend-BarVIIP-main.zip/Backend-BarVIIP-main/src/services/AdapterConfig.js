class IConfig {
  get(name) {
    throw "Implementar método";
  }
}

module.exports = IConfig;
