const UsersController = require('./user.controller')
const BarbersController = require('./barber.controller')
const AppointmentController = require('./appointment.controller')

module.exports = {
    UsersController,
    BarbersController,
    AppointmentController
}